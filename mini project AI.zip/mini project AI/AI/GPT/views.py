from django.shortcuts import render
from transformers import BlipProcessor, BlipForConditionalGeneration
from transformers import CLIPProcessor, CLIPModel
from PIL import Image
import os
import torch
blip_processor = BlipProcessor.from_pretrained("Salesforce/blip-image-captioning-base")
blip_model = BlipForConditionalGeneration.from_pretrained("Salesforce/blip-image-captioning-base")

def home(request):
    image_url = None
    caption = None
    search_result = None

    if request.method == "POST":

  
        if "image" in request.FILES:  
            img = request.FILES["image"]
            img_name = img.name


            media_path = "media"
            if not os.path.exists(media_path):
                os.makedirs(media_path)

            save_path = os.path.join(media_path, img_name)
            with open(save_path, 'wb+') as f:
                for chunk in img.chunks():
                    f.write(chunk)

            image_url = "/media/" + img_name

            pil_image = Image.open(save_path).convert("RGB")
            inputs = blip_processor(images=pil_image, return_tensors="pt")
            output = blip_model.generate(**inputs, max_length=20)
            caption = blip_processor.decode(output[0], skip_special_tokens=True)

    return render(request, "index.html", {
        "image_url": image_url,
        "caption": caption,
    })